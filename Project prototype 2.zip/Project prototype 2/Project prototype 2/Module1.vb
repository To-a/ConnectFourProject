﻿Imports System.Threading
Module Module1
    Sub Main()
        Dim Width, Height, WinCondition, Depth As Integer
        Dim PlayerOneType, PlayerTwoType As String


        Select Case SelectMode()
            Case 1
                PlayConnectN(7, 6, 4, "Human", "Human", 3)
            Case 2
                CustomizeGame(Width, Height, WinCondition)
                PlayConnectN(Width, Height, WinCondition, "Human", "Human", 3)
            Case 3
                SimulateConnectN(3, 3, 3, 3, 2, 0, 0)
            Case 4
                PlayConnectN(7, 6, 4, "Human", "MiniMax", 1)
            Case 5
                PlayConnectN(7, 6, 4, "Human", "MiniMax", 2)
            Case 6
                PlayConnectN(7, 6, 4, "Human", "MiniMax", 3)
            Case 7
                PlayConnectN(7, 6, 4, "Human", "MiniMax", 4)
            Case 8
                TestHeuristic()
            Case 9
                CustomizeEverything(Width, Height, WinCondition, PlayerOneType, PlayerTwoType, Depth)
                PlayConnectN(Width, Height, WinCondition, PlayerOneType, PlayerTwoType, Depth)
        End Select
    End Sub
    Function SelectMode()
        Dim Choice As Integer
        Do Until Choice > 0 And Choice < 10
            Console.WriteLine("Select:")
            Console.WriteLine("1 for Connect4 7x6 (standard) Player vs Player")
            Console.WriteLine("2 for ConnectN Custom board size Player vs Player")
            Console.WriteLine("3 for AI vs AI Default parameters depth 3")
            Console.WriteLine("4 for Player vs AI depth 1")
            Console.WriteLine("5 for Player vs AI depth 2")
            Console.WriteLine("6 for Player vs AI depth 3 (recomended)")
            Console.WriteLine("7 for Player vs AI depth 4")
            Console.WriteLine("8 for heuristic test")
            Console.WriteLine("9 for all custom parameters")
            Try
                Choice = Console.ReadLine
            Catch ex As Exception
                Console.WriteLine("Please enter a value!")
            End Try
            If Choice < 1 Or Choice > 9 Then
                Console.WriteLine("No such option!")
            End If
        Loop
        Console.Clear()
        Return Choice
    End Function
    Sub CustomizeGame(ByRef Width As Integer, ByRef Height As Integer, ByRef WinCondition As Integer)
        Console.WriteLine("Input board width(max 9):")
        Width = Console.ReadLine
        Console.WriteLine("Input board height(max 9):")
        Height = Console.ReadLine
        Console.WriteLine("Input win condition:")
        Console.WriteLine("(the number of counters/marks required in a row to win the game,")
        Console.WriteLine("must be equal to or less than board width and height, and more than 2)")
        WinCondition = Console.ReadLine
    End Sub
    Sub CustomizeEverything(ByRef Width As Integer, ByRef Height As Integer, ByRef WinCondition As Integer, ByRef PlayerOneType As String,
                            ByRef PlayerTwoType As String, ByRef Depth As Integer)
        Console.WriteLine("Input board width(max 9):")
        Width = Console.ReadLine
        Console.WriteLine("Input board height(max 9):")
        Height = Console.ReadLine
        Console.WriteLine("Input win condition:")
        Console.WriteLine("(the number of counters/marks required in a row to win the game,")
        Console.WriteLine("must be equal to or less than board width and height, and more than 2)")
        WinCondition = Console.ReadLine
        Console.WriteLine("Player one type:")
        Console.WriteLine("1. Human")
        Console.WriteLine("2. AI")
        If Console.ReadLine = 1 Then
            PlayerOneType = "Human"
        Else
            PlayerOneType = "MiniMax"
        End If
        Console.WriteLine("Player two type:")
        Console.WriteLine("1. Human")
        Console.WriteLine("2. AI")
        If Console.ReadLine = 1 Then
            PlayerTwoType = "Human"
        Else
            PlayerTwoType = "MiniMax"
        End If
        Console.WriteLine("Input depth")
        Depth = Console.ReadLine

    End Sub

    Public Sub PlayConnectN(ByVal BoardWidth As Integer, ByVal BoardHeight As Integer,
                     ByVal WinCondition As Integer, ByVal PlayerOneType As String,
                     ByVal PlayerTwoType As String, ByVal Depth As Integer)
            Dim ConnectN As New ConnectN(BoardWidth, BoardHeight, WinCondition)
            'Player instantiated, is then declared as human or AI
            Dim Player1 As Player
            Dim Player2 As Player
            Dim Answer As Integer
            If PlayerOneType = "Human" Then
                Player1 = New Human
            ElseIf PlayerOneType = "MiniMax" Then
                Player1 = New AI

            End If
            If PlayerTwoType = "Human" Then
                Player2 = New Human
            ElseIf PlayerTwoType = "MiniMax" Then
                Player2 = New AI
            End If

            'game loop
            Do
                ConnectN.InitializeBoard()

                Player1.SetColourRed()
                Player2.SetColourYellow()
                ConnectN.SetPOneMarkerConnectN("R")
                ConnectN.SetPTwoMarkerConnectN("Y")

                ConnectN.DisplayBoard()
                Do
                    Console.WriteLine()
                    Dim Valid As Boolean
                    Dim Input As Integer
                    Do
                        Try
                            If ConnectN.GetRedTurn = True Then
                                If PlayerOneType = "MiniMax" Then
                                    Player1.SetBoard(ConnectN.GetBoard)
                                    Player1.SetWinCondition(WinCondition)
                                    If ConnectN.GetRedTurn = True Then
                                        Player1.SetCurrentTurn("R")
                                    Else
                                        Player1.SetCurrentTurn("Y")
                                    End If

                                End If
                                Console.WriteLine("Red Turn")
                                Input = Player1.XInput(, Depth)
                                ConnectN.PlaceCounter(Input)
                            Else
                                Console.WriteLine("Yellow Turn")
                                If PlayerTwoType = "MiniMax" Then
                                    Player2.SetBoard(ConnectN.GetBoard)
                                    Player2.SetWinCondition(WinCondition)
                                    'still ok
                                    If ConnectN.GetRedTurn = True Then
                                        Player2.SetCurrentTurn("R")
                                    Else
                                        Player2.SetCurrentTurn("Y")
                                    End If

                                End If

                                Input = Player2.XInput(, Depth)
                                ConnectN.PlaceCounter(Input)
                            End If
                            If Input < 1 Or Input > BoardWidth Then
                                Valid = False
                                Console.WriteLine("Invalid input - not located within the board!")
                            ElseIf ConnectN.GetCollumnHeight(Input) > BoardHeight Then
                                Valid = False
                                Console.WriteLine("Invalid input, please choose a different collumn.")

                            Else
                                Valid = True
                            End If
                        Catch ex As Exception
                            Valid = False
                            Console.WriteLine("Please enter a value!")
                        End Try

                    Loop Until Valid
                    ConnectN.ChangeTurn()
                    ConnectN.DisplayBoard()
                Loop Until ConnectN.CheckIfGameWon(ConnectN.GetBoard) = True Or
                    ConnectN.GetGameLength = ConnectN.GetHeight * ConnectN.GetWidth
                ConnectN.ChangeTurn()
                If ConnectN.CheckIfGameWon(ConnectN.GetBoard) = False Then
                    Console.WriteLine("A draw!")
                ElseIf ConnectN.GetRedTurn = True And Player1.GetColour = "R" _
                    Or ConnectN.GetRedTurn = False And Player1.GetColour = "Y" Then
                    Console.WriteLine("Player1 wins!")
                    Player1.GameWon()
                Else
                    Console.WriteLine("Player2 wins!")
                    Player2.GameWon()
                End If
                Console.WriteLine("Scores:")
                Console.WriteLine("Player1 - " & Player1.GetScore)
                Console.WriteLine("Player2 - " & Player2.GetScore)
                Console.WriteLine()
                Console.WriteLine("Input 2 to go to menu, 1 for another game, 0 to exit")
                Answer = Console.ReadLine
            Loop Until Answer <> 1
            If Answer = 2 Then
                Call Main()
            End If
        End Sub
        Public Sub SimulateConnectN(ByVal ParameterA As Integer, ByVal ParameterB As Integer, ByVal ParameterA2 As Integer,
                ByVal ParameterB2 As Integer, ByVal NoOfGames As Integer, ByVal OneWins As Integer, ByVal TwoWins As Integer)
            Dim ConnectN As New ConnectN
            Dim Player1 As New AI
            Dim Player2 As New AI
            Dim P1Depth As Integer = 3
            Dim P2Depth As Integer = 3
            Player2.SetSurvivalPs(ParameterA, ParameterB)
            Player1.SetSurvivalPs(3, 3)

            'loop until NoOfGames
            Do
                ConnectN.InitializeBoard()
                If ConnectN.GetGameNumber Mod 2 = 1 Then
                    Player1.SetColourRed()
                    Player2.SetColourYellow()
                    ConnectN.SetPOneMarkerConnectN("R")
                    ConnectN.SetPTwoMarkerConnectN("Y")
                Else
                    Player1.SetColourYellow()
                    Player2.SetColourRed()
                    ConnectN.SetPOneMarkerConnectN("Y")
                    ConnectN.SetPTwoMarkerConnectN("R")
                End If

                'game loop
                Do
                    Dim Valid As Boolean
                    Dim Input As Integer
                    Do
                        Try
                            If ConnectN.GetRedTurn = True Then
                                If Player1.GetColour = "R" Then
                                    Player1.SetBoard(ConnectN.GetBoard)
                                    Player1.SetWinCondition(ConnectN.GetWinCondition)
                                    Player1.SetCurrentTurn("R")
                                    Input = Player1.XInput(, P1Depth)
                                    ConnectN.PlaceCounter(Input)
                                Else
                                    Player2.SetBoard(ConnectN.GetBoard)
                                    Player2.SetWinCondition(ConnectN.GetWinCondition)
                                    Player2.SetCurrentTurn("R")
                                    Input = Player2.XInput(, P2Depth)
                                    ConnectN.PlaceCounter(Input)
                                End If
                            Else
                                If Player1.GetColour = "Y" Then
                                    Player1.SetBoard(ConnectN.GetBoard)
                                    Player1.SetWinCondition(ConnectN.GetWinCondition)
                                    Player1.SetCurrentTurn("Y")
                                    Input = Player1.XInput(, P1Depth)
                                    ConnectN.PlaceCounter(Input)
                                Else
                                    Player2.SetBoard(ConnectN.GetBoard)
                                    Player2.SetWinCondition(ConnectN.GetWinCondition)
                                    Player2.SetCurrentTurn("Y")
                                    Input = Player2.XInput(, P2Depth)
                                    ConnectN.PlaceCounter(Input)
                                End If
                            End If
                            If Input < 1 Or Input > 7 Then
                                Valid = False
                                Console.WriteLine("Invalid input - not located within the board!")
                            ElseIf ConnectN.GetCollumnHeight(Input) > 6 Then
                                Valid = False
                                Console.WriteLine("Invalid input, please choose a different collumn.")

                            Else
                                Valid = True
                            End If
                        Catch ex As Exception
                            Valid = False
                            Console.WriteLine("Please enter a value!")
                        End Try

                    Loop Until Valid
                    ConnectN.ChangeTurn()
                    ConnectN.DisplayBoard()
                    ConnectN.PlayNote(Input)
                    Console.WriteLine("Scores:")
                    Console.WriteLine("Player1 - " & Player1.GetScore)
                    Console.WriteLine("Player2 - " & Player2.GetScore)
                    Console.WriteLine("Game number - " & ConnectN.GetGameNumber)
                Loop Until ConnectN.CheckIfGameWon(ConnectN.GetBoard) = True Or
                            ConnectN.GetGameLength = ConnectN.GetHeight * ConnectN.GetWidth
                ConnectN.ChangeTurn()
                If ConnectN.CheckIfGameWon(ConnectN.GetBoard) = False Then
                    Console.WriteLine("A draw!")
                ElseIf ConnectN.GetRedTurn = True And Player1.GetColour = "R" _
                            Or ConnectN.GetRedTurn = False And Player1.GetColour = "Y" Then
                    Console.WriteLine("Player1 wins!")
                    Player1.GameWon()
                Else
                    Console.WriteLine("Player2 wins!")
                    Player2.GameWon()
                End If

            Loop Until ConnectN.GetGameNumber = NoOfGames

            'display scores
            Console.WriteLine("Scores:")
            Console.WriteLine("Player1 - " & Player1.GetScore)
            Console.WriteLine("Player2 - " & Player2.GetScore)
            Console.WriteLine("simulation finished")
            Console.ReadLine()
            OneWins = Player1.GetScore
            TwoWins = Player2.GetScore
        End Sub

    Public Sub TestHeuristic()
        Dim Test As New ConnectN(7, 6, 4)
        Dim TestR As New Human
        Dim TestY As New Human
        Dim depth As Integer
        Dim answer As Char
        Console.WriteLine("Depth:")
        depth = Console.ReadLine
        Test.InitializeBoard()
        TestR.SetColourRed()
        TestY.SetColourYellow()
        Test.SetPOneMarkerConnectN("R")
        Test.SetPTwoMarkerConnectN("Y")
        Test.DisplayBoard()

        'test loop
        Do
            Test.PlaceCounter(TestR.XInput)
            Test.DisplayBoard()
            Test.ChangeTurn()
            Dim MiniTest As New Minimax(Test.GetBoard, "Y", 4)
            Console.WriteLine(MiniTest.TestHeuristic(depth))
            For n = 2 To 3
                Console.WriteLine(MiniTest.TestCheckN(Test.GetBoard, n, "Y"))
            Next
            Test.PlaceCounter(TestY.XInput)
            Test.DisplayBoard()
            Test.ChangeTurn()

            Console.WriteLine("0 to quit, any other key to continue")
            answer = Console.ReadLine
        Loop While answer <> "0"

    End Sub
    Class ConnectN
        Private BoardWidth As Integer
        Private BoardHeight As Integer
        Private WinCondition As Integer
        Private Board(,) As Char
        Private CollumnHeight() As Integer 'Keeps track of height of each collumn
        Private PlayerOneMarker As Char
        Private PlayerTwoMarker As Char
        Private RedTurn As Boolean = True 'Red starts
        Private GameLength As Integer
        Private GameNumber As Integer = 0
        Public Sub New(Optional ByVal Width As Integer = 7, Optional ByVal Height As Integer = 6, Optional ByVal Condition As Integer = 4)
            BoardWidth = Width
            BoardHeight = Height
            WinCondition = Condition
            ReDim Board(BoardWidth, BoardHeight)
            ReDim CollumnHeight(BoardWidth)
            ToneThread.Start()
        End Sub
        Public Sub SetPOneMarkerConnectN(ByVal Colour As Char)
            PlayerOneMarker = Colour
        End Sub
        Public Sub SetPTwoMarkerConnectN(ByVal Colour As Char)
            PlayerTwoMarker = Colour
        End Sub
        Public Function GetWinCondition()
            Return WinCondition
        End Function
        Public Function GetWidth()
            Return BoardWidth
        End Function
        Public Function GetHeight()
            Return BoardHeight
        End Function
        Public Function GetCollumnHeight()
            Return CollumnHeight
        End Function
        Public Function GetBoard()
            Return Board.Clone
        End Function
        Public Function GetRedTurn()
            Return RedTurn
        End Function
        Public Function GetGameLength()
            Return GameLength
        End Function
        Public Function GetGameNumber()
            Return GameNumber
        End Function
        Public Sub InitializeBoard()
            GameNumber += 1
            For X = 1 To BoardWidth
                For Y = 1 To BoardHeight
                    Board(X, Y) = " "
                Next
                CollumnHeight(X) = 0
            Next
            GameLength = 0
            RedTurn = True
            Bar = 2000
            Disp = 0
            TempBar = 2000
            TempDisp = 0
        End Sub
        Public Sub PlaceCounter(ByVal XCoordinate As Integer)
            'This procedure will not change the Board if Invalid coordinate - validation required outside
            CollumnHeight(XCoordinate) += 1
            If RedTurn Then
                Board(XCoordinate, CollumnHeight(XCoordinate)) = "R"
            Else
                Board(XCoordinate, CollumnHeight(XCoordinate)) = "Y"
            End If
        End Sub
        Public Sub ChangeTurn()
            If RedTurn Then
                RedTurn = False
            Else
                RedTurn = True
            End If
            GameLength += 1
        End Sub
        Public Function CheckIfGameWon(ByVal Board(,) As Char)
            'using a parameter for Board for minimax to use multiple Boards for simulation
            'Made to work with any Boardsize and any number of consecutive counters/marks required to win
            'This means that it can be used for scoring a Boardstate for the minimax algorithm by
            'checking for n in a row.
            Dim GameWon As Boolean = False
            Dim Match As Boolean
            For a = 1 To BoardWidth
                For b = 1 To BoardHeight
                    'checks if the game is won horizontally to the right
                    If a <= (BoardWidth - WinCondition) + 1 Then
                        Match = True
                        For c = 1 To WinCondition - 1
                            If Board(a + c, b) <> Board(a, b) Or Board(a, b) = " " Then
                                Match = False
                            End If
                        Next
                        If Match = True Then GameWon = True
                    End If
                    'checks if the game is won vertically downwards
                    If b <= (BoardHeight - WinCondition) + 1 Then
                        Match = True
                        For z = 1 To WinCondition - 1
                            If Board(a, b + z) <> Board(a, b) Or Board(a, b) = " " Then
                                Match = False
                            End If
                        Next
                        If Match = True Then GameWon = True
                    End If
                    'diagonal check 1 bottom left to top right
                    If a <= (BoardWidth - WinCondition) + 1 And
                            b <= (BoardHeight - WinCondition) + 1 Then
                        Match = True
                        For e = 1 To WinCondition - 1
                            If Board(a + e, b + e) <> Board(a, b) Or Board(a, b) = " " Then
                                Match = False
                            End If
                        Next
                        If Match = True Then GameWon = True
                    End If
                    'diagonal check 2 top left to bottom right
                    If a >= WinCondition And b <= (BoardHeight - WinCondition) + 1 Then
                        Match = True
                        For f = 1 To WinCondition - 1
                            If Board(a - f, b + f) <> Board(a, b) Or Board(a, b) = " " Then
                                Match = False
                            End If
                        Next
                        If Match = True Then GameWon = True
                    End If
                Next
            Next
            If GameWon Then
                ToneThread.Abort()
            End If
            Return GameWon
        End Function
        Public Sub DisplayBoard()
            For Y = BoardHeight To 1 Step -1
                Console.Write("|")
                For X = 1 To BoardWidth
                    If Board(X, Y) = "R" Then
                        Console.ForegroundColor = ConsoleColor.Red
                    ElseIf Board(X, Y) = "Y" Then
                        Console.ForegroundColor = ConsoleColor.Yellow
                    End If
                    Console.Write(Board(X, Y))
                    Console.ResetColor()
                    Console.Write("|")
                Next
                Console.WriteLine()
            Next
            For a = 1 To BoardWidth
                Console.Write("|" & a)
            Next
            Console.WriteLine("|")
        End Sub

        'Sound thread for bgm
        Dim ToneThread As New Thread(AddressOf ToneLoop)
        Const D As Double = 293.66
        Dim Bar As Double = 2000
        Dim Disp As Integer = 0
        Dim TempBar As Double = 2000
        Dim TempDisp As Double = 0
        Sub ToneLoop()
            Do
                Disp = TempDisp
                Bar = TempBar
                Tone(5, Bar / 8)
                Thread.Sleep(Bar * (3 / 8))
                Tone(0, Bar / 8)
                Thread.Sleep(Bar * (3 / 8))
                Tone(5, Bar / 8)
                Thread.Sleep(Bar / 4)
                Tone(0, Bar / 8)
                Thread.Sleep(Bar / 8)
                Tone(0, Bar / 8)
                Tone(4, Bar / 8)
                Thread.Sleep(Bar / 8)
            Loop

        End Sub
        Sub Tone(ByVal NoteIndex As Double, ByVal Duration As Double)
            Console.Beep(D * (2 ^ ((NoteIndex + Disp) / 12)), Duration)
        End Sub
        Public Sub PlayNote(ByVal XCoordinate As Integer)

            If TempBar > 800 Then
                TempBar -= 75
            End If
            If GameLength Mod 5 = 0 Then
                TempDisp += 1
            End If
        End Sub
    End Class

    'abstract class Player
    Public MustInherit Class Player
        Protected Colour As String
        Protected Score As Integer = 0
        Public MustOverride Function XInput(Optional ByVal Input As Integer = 1, Optional ByVal Depth As Integer = 2)
        Public Overridable Sub SetBoard(ByVal Board As Array)
        End Sub
        Public Overridable Sub SetWinCondition(ByVal ParamWinCondition As Integer)

        End Sub
        Public Overridable Sub SetCurrentTurn(ByVal ParamCurrentTurn As Char)

        End Sub
        Public Overridable Sub SetSurvivalPs(ByVal ParameterA As Integer, ByVal ParameterB As Integer)

        End Sub
        Public Sub GameWon()
            Score += 1
        End Sub
        Public Sub SetColourRed()
            Colour = "R"
        End Sub
        Public Sub SetColourYellow()
            Colour = "Y"
        End Sub
        Public Function GetColour()
            Return Colour
        End Function
        Public Function GetScore()
            Return Score
        End Function
    End Class
    Class Human : Inherits Player
        Public Sub New()
        End Sub
        Public Overrides Function XInput(Optional ByVal Input As Integer = 1, Optional ByVal Depth As Integer = 2) As Object
            Console.WriteLine("Input X Value:")
            Input = Console.ReadLine
            Return Input
        End Function
    End Class
    Class AI : Inherits Player
        Private VirtualBoard(,) As Char
        Private WinCondition As Integer
        Private CurrentTurn As Char
        Private ParameterA As Single
        Private ParameterB As Single
        Public Overrides Function XInput(Optional Input As Integer = 1, Optional ByVal Depth As Integer = 2) As Object
            Dim Minimax As New Minimax(VirtualBoard, CurrentTurn, WinCondition, ParameterA, ParameterB)
            Input = Minimax.InitialCall(Depth)
            Return Input
        End Function
        Public Overrides Sub SetBoard(ByVal Board As Array)
            VirtualBoard = Board
        End Sub
        Public Overrides Sub SetWinCondition(ByVal ParamWinCondition As Integer)
            WinCondition = ParamWinCondition
        End Sub
        Public Overrides Sub SetCurrentTurn(ByVal ParamCurrentTurn As Char)
            CurrentTurn = ParamCurrentTurn
        End Sub
        Public Overrides Sub SetSurvivalPs(ByVal ParaA As Integer, ByVal ParaB As Integer)
            ParameterA = ParaA
            ParameterB = ParaB
        End Sub
    End Class
    Class Minimax
        Protected BoardHeight As Integer
        Protected BoardWidth As Integer
        Protected InitialMaxSymbol As Char
        Protected InitialMinSymbol As Char
        Protected Board(,) As Char
        Protected WinCondition As Integer
        Private ParameterA As Single
        Private ParameterB As Single
        Public Sub New(ByVal VirtualBoard As Array, ByVal InitialTurnSymbol As Char, ByVal ParamWinCondition As Integer,
                 Optional ByVal ParaA As Single = 3, Optional ByVal ParaB As Single = 3)
            ObtainHeightWidth(VirtualBoard)
            Board = VirtualBoard
            WinCondition = ParamWinCondition
            InitialMaxSymbol = InitialTurnSymbol
            ParameterA = ParaA
            ParameterB = ParaB
            If InitialMaxSymbol = "R" Then
                InitialMinSymbol = "Y"
            Else
                InitialMinSymbol = "R"
            End If
        End Sub
        Protected Sub ObtainHeightWidth(ByVal Board As Array)
            BoardWidth = Board.GetLength(0) - 1
            BoardHeight = Board.GetLength(1) - 1
        End Sub
        Public Function InitialCall(Depth)
            Dim Hold As Double
            Dim Score As Double = -400000
            Dim BestMove As Integer
            For i = 1 To BoardWidth
                If CollumnFull(i, Board) = False Then
                    Dim BoardClone As Array = Board.Clone
                    PlaceVirtualCounter(i, 1, BoardClone, InitialMaxSymbol)
                    Hold = MiniMax(Depth, i, BoardClone, -300000, 300000, False)
                    If Hold > Score Then
                        Score = Hold
                        BestMove = i
                    End If
                End If
            Next
            Return BestMove
        End Function
        Protected Function NegaMax(ByVal Depth As Integer, ByVal Node As Integer, ByVal VirtualBoard As Array,
                                ByVal MaxSymbol As Char, ByVal NextMaxSymbol As Char, ByVal Alpha As Double,
                                ByVal Beta As Double)


            If Depth = 0 Or Terminal(VirtualBoard) = True Then
                Return Heuristic(VirtualBoard, Depth)
            End If

            Dim Score As Double = 20000
            For i = 1 To BoardWidth
                If CollumnFull(i, VirtualBoard) = False Then
                    Dim BoardCopy As Array = VirtualBoard.Clone
                    PlaceVirtualCounter(i, 1, BoardCopy, NextMaxSymbol)
                    Score = Math.Min(-NegaMax(Depth - 1, i, BoardCopy, NextMaxSymbol, MaxSymbol, Beta, Alpha), Score)
                    Alpha = Math.Min(Score, Alpha)
                    If Alpha >= Beta Then
                        Exit For
                    End If
                End If
            Next
            Return Score
        End Function
        Protected Function MiniMax(ByVal Depth As Integer, ByVal Node As Integer, ByVal VirtualBoard As Array,
                                 ByVal Alpha As Double, ByVal Beta As Double, ByVal MaxingPlayer As Boolean)
            If Depth = 0 Or Terminal(VirtualBoard) Then
                Return Heuristic(VirtualBoard, Depth)
            End If
            If MaxingPlayer Then
                Dim v As Double = -200000
                For i = 1 To BoardWidth
                    If CollumnFull(i, VirtualBoard) = False Then
                        Dim BoardCopy As Array = VirtualBoard.Clone
                        PlaceVirtualCounter(i, 1, BoardCopy, InitialMaxSymbol)
                        v = Math.Max(MiniMax(Depth - 1, i, BoardCopy, Alpha, Beta, False), v)
                        Alpha = Math.Max(Alpha, v)
                        If Beta <= Alpha Then
                            Exit For
                        End If
                    End If
                Next
                Return v
            Else
                Dim v As Double = 200000
                For i = 1 To BoardWidth
                    If CollumnFull(i, VirtualBoard) = False Then
                        Dim BoardCopy As Array = VirtualBoard.Clone
                        PlaceVirtualCounter(i, 1, BoardCopy, InitialMinSymbol)
                        v = Math.Min(MiniMax(Depth - 1, i, BoardCopy, Alpha, Beta, True), v)
                        Beta = Math.Min(Beta, v)
                        If Beta <= Alpha Then
                            Exit For
                        End If
                    End If
                Next
                Return v
            End If
        End Function
        Protected Function Heuristic(VirtualBoard, Depth)

            'board value calculation
            Dim Score As Double = 0
            If CheckN(VirtualBoard, WinCondition, InitialMaxSymbol) >= 1 Then
                Return 20000
            ElseIf CheckN(VirtualBoard, WinCondition, InitialMinSymbol) >= 1 Then
                Return -10000
            End If
            For a = 2 To WinCondition - 1
                Score += (CheckN(VirtualBoard, a, InitialMaxSymbol) * a ^ ParameterA)
            Next
            For b = 2 To WinCondition - 1
                Score -= (CheckN(VirtualBoard, b, InitialMinSymbol) * b ^ ParameterB)
            Next
            For c = 1 To BoardHeight
                If BoardWidth Mod 2 = 1 And VirtualBoard((BoardWidth + 1) / 2, c) = InitialMaxSymbol Then
                    Score += 1
                ElseIf BoardWidth Mod 2 = 0 And VirtualBoard(BoardWidth / 2, c) = InitialMaxSymbol Then
                    Score += 1
                End If
                If BoardWidth Mod 2 = 1 And VirtualBoard((BoardWidth + 1) / 2, c) = InitialMinSymbol Then
                    Score -= 1
                ElseIf BoardWidth Mod 2 = 0 And VirtualBoard(BoardWidth / 2, c) = InitialMinSymbol Then
                    Score -= 1
                End If
            Next

            Return Score
        End Function
        Protected Function CheckN(ByVal VirtualBoard, ByVal N, ByVal Symbol)
            Dim NConsecutive As Integer = 0
            Dim Match As Boolean

            For a = 1 To BoardWidth
                For b = 1 To BoardHeight - 1
                    'checks horizontally to the right
                    If a <= (BoardWidth - N) + 1 Then
                        Match = True
                        For c = 1 To N - 1
                            If VirtualBoard(a + c, b) <> VirtualBoard(a, b) Or VirtualBoard(a, b) = " " Or VirtualBoard(a, b) <> Symbol Then
                                Match = False
                            End If
                        Next
                        If Match = True Then NConsecutive += 1
                    End If
                    'checks vertically downwards
                    If b <= (BoardHeight - N) + 1 Then
                        Match = True
                        For d = 1 To N - 1
                            If VirtualBoard(a, b + d) <> VirtualBoard(a, b) Or VirtualBoard(a, b) = " " Or VirtualBoard(a, b) <> Symbol Then
                                Match = False
                            End If
                        Next
                        If Match = True Then NConsecutive += 1
                    End If
                    'diagonal check 1 bottom left to top right
                    If a <= (BoardWidth - N) + 1 And
                            b <= (BoardHeight - N) + 1 Then
                        Match = True
                        For e = 1 To N - 1
                            If VirtualBoard(a + e, b + e) <> VirtualBoard(a, b) Or VirtualBoard(a, b) = " " Or VirtualBoard(a, b) <> Symbol Then
                                Match = False
                            End If
                        Next
                        If Match = True Then NConsecutive += 1
                    End If
                    'diagonal check 2 top left to bottom right
                    If a >= N And b <= (BoardHeight - N) + 1 Then
                        Match = True
                        For f = 1 To N - 1
                            If VirtualBoard(a - f, b + f) <> VirtualBoard(a, b) Or VirtualBoard(a, b) = " " Or VirtualBoard(a, b) <> Symbol Then
                                Match = False
                            End If
                        Next
                        If Match = True Then NConsecutive += 1
                    End If
                Next
            Next

            Return NConsecutive
        End Function
        Protected Function Terminal(VirtualBoard)
            Dim Match As Boolean = True
            Dim N As Integer = WinCondition
            Dim GameWon As Boolean = False
            For a = 1 To BoardWidth
                For b = 1 To BoardHeight
                    'checks if the game is won horizontally to the right
                    If a <= (BoardWidth - WinCondition) + 1 Then
                        Match = True
                        For c = 1 To WinCondition - 1
                            If VirtualBoard(a + c, b) <> VirtualBoard(a, b) Or VirtualBoard(a, b) = " " Then
                                Match = False
                            End If
                        Next
                        If Match = True Then GameWon = True
                    End If
                    'checks if the game is won vertically downwards
                    If b <= (BoardHeight - WinCondition) + 1 Then
                        Match = True
                        For d = 1 To WinCondition - 1
                            If VirtualBoard(a, b + d) <> VirtualBoard(a, b) Or VirtualBoard(a, b) = " " Then
                                Match = False
                            End If
                        Next
                        If Match = True Then GameWon = True
                    End If
                    'diagonal check 1 bottom left to top right
                    If a <= (BoardWidth - WinCondition) + 1 And
                            b <= (BoardHeight - WinCondition) + 1 Then
                        Match = True
                        For e = 1 To WinCondition - 1
                            If VirtualBoard(a + e, b + e) <> VirtualBoard(a, b) Or VirtualBoard(a, b) = " " Then
                                Match = False
                            End If
                        Next
                        If Match = True Then GameWon = True
                    End If
                    'diagonal check 2 top left to bottom right
                    If a >= WinCondition And b <= (BoardHeight - WinCondition) + 1 Then
                        Match = True
                        For f = 1 To WinCondition - 1
                            If VirtualBoard(a - f, b + f) <> VirtualBoard(a, b) Or VirtualBoard(a, b) = " " Then
                                Match = False
                            End If
                        Next
                        If Match = True Then GameWon = True
                    End If
                Next
            Next

            Return GameWon

        End Function
        Protected Function CollumnFull(Collumn, VirtualBoard)
            If VirtualBoard(Collumn, BoardHeight) = " " Then
                Return False
            Else
                Return True
            End If
        End Function
        Protected Sub PlaceVirtualCounter(Collumn, CurrentHeight, VirtualBoard, CurrentSymbol)
            If VirtualBoard(Collumn, CurrentHeight) = "R" Or VirtualBoard(Collumn, CurrentHeight) = "Y" Then
                PlaceVirtualCounter(Collumn, CurrentHeight + 1, VirtualBoard, CurrentSymbol)
            Else
                VirtualBoard(Collumn, CurrentHeight) = CurrentSymbol
            End If
        End Sub
        Public Function TestHeuristic(Depth)
            Return Heuristic(Board, Depth)
        End Function
        Public Function TestCheckN(VirtualBoard, N, Symbol)
            Return CheckN(VirtualBoard, N, Symbol)
        End Function
    End Class

End Module





















